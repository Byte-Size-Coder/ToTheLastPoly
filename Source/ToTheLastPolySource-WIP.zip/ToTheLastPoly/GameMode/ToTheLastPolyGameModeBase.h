// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "ToTheLastPolyGameModeBase.generated.h"

/**
 * 
 */
UCLASS()
class TOTHELASTPOLY_API AToTheLastPolyGameModeBase : public AGameModeBase
{
	GENERATED_BODY()
	
};
